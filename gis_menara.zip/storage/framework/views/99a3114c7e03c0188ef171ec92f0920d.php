

<?php $__env->startSection('content'); ?>
   <div class="container-xxl flex-grow-1 container-p-y">
   
      <?php echo e(Breadcrumbs::render('menara')); ?>

      
       <div class="row">
           <div class="col-lg-12 mb-4 order-0">
<!-- Hoverable Table rows -->
<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show text-dark" role="alert">
  <?php echo e(session('success')); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session()->has('LoginError')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <?php echo e(session('LoginError')); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<div class="card">
   <h5 class="card-header">Data menara</h5>
   <div class="table-responsive text-nowrap">
  <div class="d-flex align-items-center justify-content-between">
    <div class="col-md-8">
      <a href="menara/create" class="btn btn-primary ms-3 mb-2">Tambah data</a>
      <a href="#" class="btn btn-primary ms-3 mb-2" data-bs-toggle="modal" data-bs-target="#smallModal" >Cetak</a>
    </div>
    <!-- Modal -->
    <form method="GET" action="/menara">
           <div class="md-3 input-group col-3 input-group-merge ">
             <span class="input-group-text border-0 shadow-none" id="basic-addon-search31"><i class="bx bx-search"></i></span>
             <input
               type="text"
               name="search"
               class="form-control border-0 shadow-none"
               placeholder="Cari Sesuatu..."
               aria-label="Cari Sesuatu..."
               value="<?php echo e(request('search')); ?>"
               aria-describedby="basic-addon-search31"
             />
           </div>   
    </form> 
  </div>
     <table class="table table-hover">
       <thead>
         <tr>
           <th>#</th>
           <th>Foto</th>
           <th>Site Name</th>
           <th>Provider</th>
           <th>Kecamatan</th>
           <th>Alamat</th>
           <th>Tinggi</th>
           <th>Jenis Menara</th>
           <th>Tahun</th>
           <th>Latitude</th>
           <th>Longitute</th>
           <th>Aksi</th>
         </tr>
       </thead>
       <tbody class="table-border-bottom-0">
        <?php if(count($menaras)>0): ?>
           <?php $__currentLoopData = $menaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
          <input type="hidden" class="delete_id" value="<?php echo e($menara->id); ?>">
           <td><?php echo e($loop->iteration); ?></td>
           <td><?php if($menara->foto == ""): ?>
              none
            <?php else: ?>
            <img src="<?php echo e(asset('storage/'.$menara->foto)); ?>" class="w-px-40 h-auto "  alt=""> </td>
            <?php endif; ?>
            <td><?php echo e($menara->nama); ?></td>
           <td><?php echo e($menara->provider->name); ?></td>
           <td><?php echo e($menara->kecamatan->nama); ?></td>
           <td><?php echo e($menara->alamat); ?></td>
           <td><?php echo e($menara->tinggi); ?> M</td>
           <td> <?php echo e($menara->Jenis->nama); ?> Kaki</td>
           <td><?php echo e($menara->tahun); ?></td>
           <td><?php echo e($menara->lat); ?></td>
           <td><?php echo e($menara->long); ?></td>
          
           <td>
             <div class="dropdown">
               <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                 <i class="bx bx-dots-vertical-rounded"></i>
               </button>
               <div class="dropdown-menu">
                 <a  class="dropdown-item editbtn" href="/menara/<?php echo e($menara->nama); ?>/edit"
                   ><i class="bx bx-edit-alt me-1"></i> Edit</a
                 >
                 <a  class="dropdown-item editbtn" href="/menara/<?php echo e($menara->nama); ?>"
                  ><i class="bx bx-eye me-1"></i> Detail</a
                >

                 <form action="menara/<?php echo e($menara->id); ?>" method="post" >
                   <?php echo method_field('delete'); ?>
                   <?php echo csrf_field(); ?>
                 <button class="dropdown-item btndelete" 
                   ><i class="bx bx-trash me-1"></i> Delete</button>
                 </form>
                 
               </div>
             </div>
           </td>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php else: ?>
           <td colspan="10">
            <h5 class="text-center">Tidak ada data</h5>
           </td>
          <?php endif; ?>
         </tr>
       </tbody>
     </table>
     <div class="container mt-2">
      <?php echo e($menaras->links('pagination::bootstrap-5')); ?>

    </div>
   </div>
 </div>
</div>
</div>
</div>

<div class="modal fade" id="smallModal" tabindex="-1" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel2">Cetak Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="/menaraCetak" method="get">
      <div class="modal-body">
        <div class="col-12 mb-3">
          <label for="provider" class="form-label">Provider</label>
          <select class="form-control <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="provider_id" name="provider_id" >
            <option value="">== Pilih Provider ==</option>
          <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(old('provider_id') == $provider->id): ?>
          <option value="<?php echo e($provider->id); ?>" selected><?php echo e($provider->name); ?></option>
          <?php else: ?>
          <option value="<?php echo e($provider->id); ?>"><?php echo e($provider->name); ?></option>
          <?php endif; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
        <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12 text-center">
        <label for="provider" class="form-label">atau</label>
        </div>
        <div class="col-12 mb-3">
          <label for="provider" class="form-label">Kecamatan</label>
          <select class="form-control <?php $__errorArgs = ['kecamatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kecamatan_id" name="kecamatan_id" >
            <option value="">== Pilih Kecamatan ==</option>
          <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(old('kecamatan_id') == $kecamatan->id): ?>
          <option value="<?php echo e($kecamatan->id); ?>" selected><?php echo e($kecamatan->nama); ?></option>
          <?php else: ?>
          <option value="<?php echo e($kecamatan->id); ?>"><?php echo e($kecamatan->nama); ?></option>
          <?php endif; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['kecamatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
        <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

       
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
          Keluar
        </button>
        <button type="submit" target="blank" class="btn btn-primary">Cetak</button>
      </div>
      </form>

    </div>
  </div>
</div>
 <!--/ Hoverable Table rows -->
   
   <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
          
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('.btndelete').click(function (e) {
            e.preventDefault();

            var deleteid = $(this).closest("tr").find('.delete_id').val();

            swal({
                    title: "Apakah anda yakin?",
                    text: "Setelah dihapus, Anda tidak dapat memulihkan data ini lagi!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {

                        var data = {
                            "_token": $('input[name=_token]').val(),
                            'id': deleteid,
                        };
                        $.ajax({
                            type: "DELETE",
                            url: 'menara/' + deleteid,
                            data: data,
                            success: function (response) {
                                swal(response.status, {
                                        icon: "success",
                                    })
                                    .then((result) => {
                                        location.reload();
                                    });
                            }
                        });
                    }
                });
        });

      
    });

</script>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/provider/menara/index.blade.php ENDPATH**/ ?>