

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="/dasboard">Dasboard</a>
        </li>
        <li class="breadcrumb-item">
          <a href="/retribusi">Data Retribusi</a>
        </li>
        <li class="breadcrumb-item active">Kirim Tagihan</li>
      </ol>


        <div class="row">
            <div class="col-lg-6 mb-4 order-0">
                <div class="col-xl">
                    <div class="card mb-4">
                      <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Kirim Tagihan Retribusi</h5>
                       
                      </div>
                      <div class="card-body">
                        <form action="/kirimEmail" method="POST" enctype="multipart/form-data">
                           <?php echo e(csrf_field()); ?>

                            <?php echo csrf_field(); ?>
                            <div class="row g-2">
                            <div class="mb-3">
                                <label for="provider" class="form-label">Provider</label>
                                <select class="form-control <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="provider_id" name="provider_id" >
                                    <option value="">== Pilih Provider ==</option>
                                  <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if(old('provider') == $provider->id): ?>
                                  <option value="<?php echo e($provider->id); ?>" selected><?php echo e($provider->name); ?></option>
                                  <?php else: ?>
                                  <option value="<?php echo e($provider->id); ?>"><?php echo e($provider->name); ?></option>
                                  <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
          
                          <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-company">Tagihan</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-company2" class="input-group-text"
                                >Rp.</span>
                              <select class="form-control <?php $__errorArgs = ['tagihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tagihan" name="tagihan" >
                            </select>
                              <?php $__errorArgs = ['tagihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="mb-3 ">
                            <label class="form-label" for="basic-icon-default-fullname">Jatuh Tempo</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-fullname2" class="input-group-text"
                                ><i class="bx bx-date"></i
                              ></span>
                              <input
                                type="datetime-local"
                                name="jatuh_tempo"
                                class="form-control <?php $__errorArgs = ['jatuh_tempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="basic-icon-default-fullname"
                                placeholder="Masukkan Nama Perusahaan"
                                aria-label="Masukkan Nama Perusahaan"
                                aria-describedby="basic-icon-default-fullname2"
                                value="<?php echo e(old('jatuh_tempo')); ?>"
                              />
                              <?php $__errorArgs = ['jatuh_tempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                        
                        
                          <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              
              <!-- / Content -->
                      </div>
                    </div>
                  
                  <!-- / Content -->

            </div>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
          
            <script>


             $(document).ready(function() {
                $('#provider_id').on('change', function(){
                    var kode_provider = $(this).val();
                  
                    if (kode_provider) {
                        $.ajax({
                            url:'/email/' + kode_provider,
                            type: 'GET',
                            data: {
                                '_token': '<?php echo e(csrf_token()); ?>'
                            },
                            dataType: 'json',
                            success: function(data){
                               if (data) {
                                // console.log(data);
                                $('#email').empty();
                              
                                $.each(data,function(nama,kode){
                    $("#email").append('<option value="'+kode.email+'">'+kode.email+'</option>');
                });
                               } else {
                                
                               }
                            }
                        });
                    } else{

                    }
                    });
                });

                
                $(document).ready(function() {
                $('#provider_id').on('change', function(){
                    var kode_provider = $(this).val();
                   
                  console.log(kode_provider);
                    if (kode_provider) {
                        $.ajax({
                            url:'/total/' + kode_provider,
                            type: 'GET',
                            data: {
                                '_token': '<?php echo e(csrf_token()); ?>'
                            },
                            dataType: 'json',
                            success: function(data){
                               if (data) {
                                console.log(data);
                                $('#tagihan').empty();
                                $('#tagihan').append('<option value="'+data+'">'+data+'</option>');
                               } else {
                                
                               }
                            }
                        });
                    } else{

                    }
                    });
                });
            </script>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/provider/retribusi/buat.blade.php ENDPATH**/ ?>