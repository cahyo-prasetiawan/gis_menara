

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-0 mb-5" >
       
       <div class="col-md-12 "  id="map">
                 
       </div>
      
   
</div>
<!-- Carousel End -->


<!-- Features Start -->
<div class="container-xxl py-5">
   <div class="container">
       <div class="row g-0 feature-row justify-content-center">
           <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.1s">
               <div class="feature-item border h-100 p-5">
                   <div class="btn-square bg-light rounded-circle mb-4" style="width: 64px; height: 64px;">
                    <img class="img-fluid" src="<?php echo e(asset('../assetHome/img/tower.png')); ?>" alt="Icon">
                   </div>
                   <h5 class="mb-3">Jumlah Menara</h5>
                   <p class="mb-0 text-center"><?php echo e(@count($tampil)); ?></p>
                   <h5 class="mb-3 text-center">Menara</h5>
               </div>
           </div>
           <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.3s">
               <div class="feature-item border h-100 p-5">
                   <div class="btn-square bg-light rounded-circle mb-4" style="width: 64px; height: 64px;">
                       <img class="img-fluid" src="<?php echo e(asset('../assetHome/img/dis.png')); ?>" alt="Icon">
                   </div>
                   <h5 class="mb-3">Tagihan Retribusi</h5>
                   <?php
                   function rupiah($angka)
               {
                   // $prefix = $prefix ? $prefix : 'Rp. ';
                   // $nominal = $this->attributes[$field];
                   // return $prefix . number_format($nominal, 0, ',', '.');
                   $hasil = "Rp. " . number_format($angka, '2', ',' , '.');
                   return $hasil;
               }
               ?>
               <?php if(count($retribusis)>0): ?>
                   <p class="mb-0"><?php echo e(rupiah($tagihan)); ?></p>
                   <?php else: ?>
                   <p class="mb-0">Tidak Ada</p>
                   <?php endif; ?>
               </div>
           </div>
           <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.5s">
               <div class="feature-item border h-100 p-5">
                   <div class="btn-square bg-light rounded-circle mb-4" style="width: 64px; height: 64px;">
                    <img class="img-fluid" src="<?php echo e(asset('../assetHome/img/map.png')); ?>" alt="Icon">
                   </div>
                   <h5 class="mb-3">Total Kecamatan</h5>
                   
                   <p class="mb-0 text-center"><?php echo e(@count($total_kecamatan)); ?></p>
                   <h5 class="mb-3 text-center">Kecamatan</h5>
               </div>
           </div>
           
       </div>
   </div>
</div>
<!-- Features End -->


<!-- Service Start -->
<div class="container-xxl py-5">
   <div class="container">
       <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
          
           <h1 class=" mb-2">Daftar Menara</h1>
           <a href="/halmenara" class="btn btn-primary mb-3">Lihat Semua</a>
       </div>
       <div class="row g-4">

        <?php $__currentLoopData = $tampil1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="team-item rounded overflow-hidden pb-4">
                <img class="img-fluid m1-1" src="<?php echo e(asset('storage/'.$menara->foto)); ?>"  width="80px;" style="margin: 1px" alt="">
                <h6 style="margin:4px;"><?php echo e($menara->nama); ?></h6>
                <span class="text-primary"><?php echo e($menara->kecamatan->nama); ?></span><br>
                <a class="btn btn-primary justify-content-end" style="font-size:10px;" href="/lihat/<?php echo e($menara->id); ?>">Detail</a>
                
            </div>
        </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
    
       </div>
   </div>
</div>
<!-- Service End -->





<!-- Quote Start -->
<div class="container-xxl py-5">
   <div class="container">
    <div class="row g-5">
        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
            <p class="fs-5 fw-medium text-primary">Kontak Kami</p>
            <h1 class="display-8 mb-4">Dinas Komunikasi, Informatika dan Persandian Bungo</h1>
            <p>Diskominfo di daerah kabupaten bungo 
             awalnya berasal dari dalam bagian kantor bupati yang termasuk humas disana. Lalu setelah itu humas di
              pecah dan dijadikan kantor terpisah dari dalam bagian kantor bupati. Yang dimana kantor ini di dirikan bangunannya
               sendiri lalu dilakukannya pembagian bidang untuk setiap pegawai negeri sipil yang bekerja. 
              </p>
            <p class="mb-4"> Kantor dinas kominfo
             berdiri pada tahun 2020 dan sudah berusia 2 tahun yang masih dipimpin oleh bapak Zainadi, S.Pd., MM.</p>
            <a class="d-inline-flex align-items-center rounded overflow-hidden border border-primary" href="">
                <span class="btn-lg-square bg-primary" style="width: 30px; height: 30px;">
                    <i class="fa fa-phone-alt text-white"></i>
                </span>
                <span class="fs-5 fw-medium mx-4">+012 345 6789</span>
            </a>
            <a class="d-inline-flex align-items-center rounded overflow-hidden border border-primary" href="">
             <span class="btn-lg-square bg-primary" style="width: 30px; height: 30px;">
                 <i class="fa fa-envelope text-white"></i>
             </span>
             <span class="fs-5 fw-medium mx-4">Kominfo@gmail</span>
         </a>
        </div>
        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
            <h2 class="mb-1">Kirim Pesan</h2>
            <div class="row g-3">
             <form action="/pesan" method="POST" enctype="multipart/form-data">
                 <?php echo csrf_field(); ?>
                 <div class="col-12 ms-0 mb-1">
                 <input type="hidden"  name="provider_id" value="<?php echo e(Auth::user()->provider_id); ?>">
                 </div>
                 <div class="col-sm-12 mb-2">
                     <div class="form-floating">
                         <select class="form-select  <?php $__errorArgs = ['laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="service" name="laporan">
                             <option value="">=== Pilih ====</option>
                             <option value="Kesalahan Data Menara">Kesalahan Data Menara</option>
                             <option value="Kesalahan Tagihan Retribusi">Kesalahan Tagihan Retribusi</option>
                         </select>
                         <label for="service">Pilih Laporan</label>
                         <?php $__errorArgs = ['laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div class="invalid-feedback">
                         <?php echo e($message); ?>

                         </div>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                 </div>
                 
                    <div class="col-12 mb-1">
                        <div class="form-floating">
                            <textarea class="form-control  <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pesan" id="message"
                                style="height: 130px"> <?php echo e(old('pesan')); ?></textarea>
                            <label for="message">Masukkan Pesan</label>
                            <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 text-center">
                        <button class="btn btn-primary w-100 py-2" type="submit">Kirim Pesan</button>
                    </div>
                 </form>
             
            </div>
        </div>
    </div>
   </div>
</div>
<!-- Quote Start -->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('interface.parsial.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/interface/index.blade.php ENDPATH**/ ?>