

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="/dasboard">Dasboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="/kecamatan">Data Kecamatan</a>
            </li>
            <li class="breadcrumb-item active">Edit Data <?php echo e($kecamatan->nama); ?></li>
          </ol>

        <div class="row">
            <div class="col-lg-6 mb-4 order-0">
                <div class="col-xl">
                    <div class="card mb-4">
                      <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Edit Data Kecamatan</h5>
                      </div>
                      <div class="card-body">
                        <form action="/kecamatan/<?php echo e($kecamatan->id); ?>/edit" method="POST" enctype="multipart/form-data">
                            <?php echo e(method_field('PUT')); ?>

                            <?php echo csrf_field(); ?>
                          <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-fullname">Nama Kecamatan</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-fullname2" class="input-group-text"
                                ><i class="bx bx-notepad"></i
                              ></span>
                              <input
                                type="text"
                                name="nama"
                                class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="basic-icon-default-fullname"
                                placeholder="Masukkan Nama Kecamatan"
                                aria-label="Masukkan Nama Kecamatan"
                                aria-describedby="basic-icon-default-fullname2"
                                value="<?php echo e(old('nama',$kecamatan->nama )); ?>"
                              />
                              <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-fullname">File Geojson</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-fullname2" class="input-group-text"
                                ><i class="bx bx-file"></i
                              ></span>
                              <input
                                type="file"
                                name="geojson"
                                class="form-control <?php $__errorArgs = ['geojson'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="basic-icon-default-fullname"
                                placeholder="Masukkan geojson Kecamatan"
                                aria-label="Masukkan geojson Kecamatan"
                                aria-describedby="basic-icon-default-fullname2"
                                value="<?php echo e(old('geojson',$kecamatan->geojson)); ?>"
                              />
                              <?php $__errorArgs = ['geojson'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-text">File : <?php echo e($kecamatan->geojson); ?></div>
                          </div>
                          <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-fullname">Warna</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-fullname2" class="input-group-text"
                                ><i class="bx bx-brush"></i
                              ></span>
                              <input
                                type="color"
                                name="warna"
                                class="form-control <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="basic-icon-default-fullname"
                                placeholder="Masukkan Warna"
                                aria-label="Masukkan Warna"
                                aria-describedby="basic-icon-default-fullname2"
                                value="<?php echo e(old('warna',$kecamatan->warna)); ?>"
                              />
                              <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>

                          <div class="mb-3">
                            <label for="provider" class="form-label">Status</label>
                            <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" >
                              <?php if(old('status', $kecamatan->status)  == $kecamatan->status): ?>
                              <option value="<?php echo e($kecamatan->status); ?>" selected> <?php if( $kecamatan->status == '0'): ?> Aktif <?php else: ?> Tidak Aktif <?php endif; ?></option>
                                  <?php if($kecamatan->status == '0'): ?>
                                  <option value="1"  <?php echo e(($kecamatan->status == "0")? "checked" : ""); ?>>Tidak Aktif</option>
                                  <?php else: ?>
                                  <option value="0"  <?php echo e(($kecamatan->status == "1")? "checked" : ""); ?>>Aktif</option>
                                  <?php endif; ?>
                              <?php else: ?>
                             
                              <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                         
                         

                          <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- / Content -->
            </div>
            <script>
              function previewImage()
             {
             const image = document.querySelector('#image');
             const imgPreview = document.querySelector('.img-preview');

             imgPreview.style.display = 'block';

             const oFReader = new FileReader();
             oFReader.readAsDataURL(image.files[0]);

             oFReader.onload = function(oFREvent) {
               imgPreview.src = oFREvent.target.result;
             }
             }
           </script>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/kecamatan/edit.blade.php ENDPATH**/ ?>