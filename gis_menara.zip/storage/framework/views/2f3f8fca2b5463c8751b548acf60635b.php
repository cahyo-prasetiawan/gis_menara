

<?php $__env->startSection('content'); ?>
   <div class="container-xxl flex-grow-1 container-p-y">
   
      <?php echo e(Breadcrumbs::render('pesan')); ?>

      
       <div class="row">
           <div class="col-lg-12 mb-4 order-0">
<!-- Hoverable Table rows -->
<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show text-dark" role="alert">
  <?php echo e(session('success')); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session()->has('LoginError')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <?php echo e(session('LoginError')); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<div class="card">
   <h5 class="card-header">Data Pesan</h5>
   <div class="table-responsive text-nowrap">
  <div class="d-flex align-items-center justify-content-between">
    <!-- Modal -->
  </div>
     <table class="table table-hover">
       <thead>
         <tr>
           <th>#</th>
           <th>Provider</th>
           <th>laporan</th>
           <th>pesan</th>
           <th>Aksi</th>
         </tr>
       </thead>
       <tbody class="table-border-bottom-0">
        <?php if(count($pesans)>0): ?>
           <?php $__currentLoopData = $pesans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
          <input type="hidden" class="delete_id" value="<?php echo e($pesan->id); ?>">
           <td><?php echo e($loop->iteration); ?></td>
           <td><?php echo e($pesan->provider->name); ?></td>
           <td><?php echo e($pesan->laporan); ?></td>
           <td><?php echo e($pesan->pesan); ?></td>
           <td>
             <div class="dropdown">
               <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                 <i class="bx bx-dots-vertical-rounded"></i>
               </button>
               <div class="dropdown-menu">
                 <form action="pesan/<?php echo e($pesan->id); ?>" method="post" >
                   <?php echo method_field('delete'); ?>
                   <?php echo csrf_field(); ?>
                 <button class="dropdown-item btndelete" 
                   ><i class="bx bx-trash me-1"></i> Delete</button>
                 </form>
               </div>
             </div>
           </td>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php else: ?>
           <td colspan="10">
            <h5 class="text-center">Tidak ada data</h5>
           </td>
          <?php endif; ?>
         </tr>
       </tbody>
     </table>
     <div class="container mt-2">
     
    </div>
   </div>
 </div>
</div>
</div>
</div>


 <!--/ Hoverable Table rows -->
   
   <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
          
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('.btndelete').click(function (e) {
            e.preventDefault();

            var deleteid = $(this).closest("tr").find('.delete_id').val();

            swal({
                    title: "Apakah anda yakin?",
                    text: "Setelah dihapus, Anda tidak dapat memulihkan data ini lagi!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {

                        var data = {
                            "_token": $('input[name=_token]').val(),
                            'id': deleteid,
                        };
                        $.ajax({
                            type: "DELETE",
                            url: 'pesan/' + deleteid,
                            data: data,
                            success: function (response) {
                                swal(response.status, {
                                        icon: "success",
                                    })
                                    .then((result) => {
                                        location.reload();
                                    });
                            }
                        });
                    }
                });
        });

      
    });

</script>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/pesan/index.blade.php ENDPATH**/ ?>