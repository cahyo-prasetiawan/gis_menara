

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
   
        <?php echo e(Breadcrumbs::render('dasboard')); ?>

        
        <div id="flash" data-flash="<?php echo e(session('berhasil')); ?>"> </div>
        <div class="row">
            <div class="col-lg-8 mb-4 order-0">
                <div class="card">
                  <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                      <div class="card-body">
                        <h5 class="card-title text-primary">Selamat Datang, 
                          <?php if(Str::length(Auth::guard('user')->user()) > 0 ): ?>
                         <?php echo e(Auth::guard('user')->user()->name); ?>

                          <?php elseif(Str::length(Auth::guard('pengguna')->user()) > 0): ?>
                          <?php echo e(Auth::guard('pengguna')->user()->name); ?>

                          <?php endif; ?>
                          ! 🎉</h5>
                        <p class="mb-4">
                          Anda Memiliki <span class="fw-bold"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span> Notifikasi Hari Ini. Cek Notifikasi Dilonceng Atau Ke Profil Anda.
                        </p>

                        <a href="/myprofile" class="btn btn-sm btn-outline-primary">Profil Saya</a>
                      </div>
                    </div>
                    <div class="col-sm-5 text-center text-sm-left">
                      <div class="card-body pb-0 px-0 px-md-4">
                        <img
                          src="../assets/img/illustrations/man-with-laptop-light.png"
                          height="140"
                          alt="View Badge User"
                          data-app-dark-img="illustrations/man-with-laptop-dark.png"
                          data-app-light-img="illustrations/man-with-laptop-light.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-4 col-md-4 order-1">
                <div class="row">
                  <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                      <div class="card-body">
                        <div class="card-title d-flex align-items-start justify-content-between">
                          <div class="avatar flex-shrink-0">
                            <i class="bg bg-blue bx bx-broadcast"></i>
                          </div>
                          <div class="dropdown">
                            <button
                              class="btn p-0"
                              type="button"
                              id="cardOpt3"
                              data-bs-toggle="dropdown"
                              aria-haspopup="true"
                              aria-expanded="false"
                            >
                              <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
                              <a class="dropdown-item" href="/menara">Lihat Detail</a>
                            </div>
                          </div>
                        </div>
                        <span class="fw-semibold d-block mb-1">Total Menara</span>
                        <h3 class="card-title mb-2 text-center"><?php echo e($jumlah); ?> </h3>
                        <small class="text-success fw-semibold"><i class="bx bx-up-arrow-alt"></i> +<?php echo e($sekarang); ?> Menara</small>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                      <div class="card-body">
                        <div class="card-title d-flex align-items-start justify-content-between">
                          <div class="avatar flex-shrink-0">
                            <img
                              src="../assets/img/icons/unicons/wallet-info.png"
                              alt="Credit Card"
                              class="rounded"
                            />
                          </div>
                          <div class="dropdown">
                            <button
                              class="btn p-0"
                              type="button"
                              id="cardOpt6"
                              data-bs-toggle="dropdown"
                              aria-haspopup="true"
                              aria-expanded="false"
                            >
                              <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                              <a class="dropdown-item" href="/laporan">Lihat Detail</a>
                            </div>
                          </div>
                        </div>
                        <?php
                        function rupiah($angka)
                    {
                        // $prefix = $prefix ? $prefix : 'Rp. ';
                        // $nominal = $this->attributes[$field];
                        // return $prefix . number_format($nominal, 0, ',', '.');
                        $hasil = "Rp. " . number_format($angka, '2', ',' , '.');
                        return $hasil;
                    }
                    ?>
                        <span>Jumlah Tagihan</span>
                        <h6 class="card-title text-nowrap mb-1"><?php echo e(rupiah($retribusi)); ?></h6>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-12 col-md-4 order-1">
                <div class="row">
                  <div class="col-lg-8 col-md-12 col-6 mb-4" >
                    <div class="card">
                      <div class="card-body">
                        <div class="grafik" id="grafik"></div>
                      </div>
                    </div>
                   
                  </div>
                  <div class="col-lg-4 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                          <div class="text-center">
                            <div class="dropdown">
                            
                            </div>
                          </div>
                        </div>
                        <div id="Chart"></div>
                        
  
                        <div class="d-flex px-xxl-4 px-lg-2 p-4 gap-xxl-3 gap-lg-1 gap-3 justify-content-between">
                          <div class="d-flex">
                            <div class="me-2">
                              <span class="badge bg-label-primary p-2"><i class="bx bx-dollar text-primary"></i></span>
                            </div>
                            <div class="d-flex flex-column">
                              <small>2023</small>
                              <h6 class="mb-0"> <?php echo e(json_encode( rupiah($total[2]))); ?></h6>
                            </div>
                          </div>
                          <div class="d-flex">
                            <div class="me-2">
                              <span class="badge bg-label-info p-2"><i class="bx bx-wallet text-info"></i></span>
                            </div>
                            <div class="d-flex flex-column">
                              <small>2022</small>
                              <h6 class="mb-0"> <?php echo e(json_encode( rupiah($total[1]))); ?></h6>
                            </div>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
          

        </div>

        
        
    </div>
  

<script>

  //hybrid : s,h
  //satelite : s
  //street : m
  //terain : p
  
  //  var map = L.map('map').setView([-1.5016624,102.1162189], 9);
  //  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  //                                  maxZoom: 24,
  //                                  attribution: '© OpenStreetMap'
  //                                }).addTo(map);
  
  
  // // var towerIcon = L.icon({
  // //   iconUrl: '/storage/pin.gif',
  // //     iconSize:     [20, 40], // size of the icon
  // // });
  // <?php $__currentLoopData = $menaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  // var towerIcon<?php echo e($menara->id); ?> = L.icon({
  //   iconUrl: '<?php echo e(asset('/storage/'.$menara->provider->icon)); ?>',
  //     iconSize:     [30, 40], // size of the icon
  // });
  // L.marker([<?php echo e($menara->lat); ?>,<?php echo e($menara->long); ?>], {icon: towerIcon<?php echo e($menara->id); ?>}).addTo(map)
  // .bindPopup("<img class='img-thumbnail' src='<?php echo e(asset('storage/'.$menara->foto)); ?>'><br><b>Lolasi Menara Ini</b><br><?php echo e($menara->alamat); ?>");
  // <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
  //     var geojson_id = '';

  //   <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  //   // proses baca file json yang ada di path /asssets/files/
  //   // sesuaikan path ini dengan lokasi tempat kalian menyimpan file data geojson
  //   $.getJSON("<?php echo e(asset('storage/'.$kecamatan->geojson)); ?>", function(data){
  //       //deklarasi variable map dengan fungsi L.map
  //       geojson_id = data;//variabel yang isinya data geojson
        
  //       //style untuk geojson, silahkan ubah sesuai kebutuhan
  //   function style(feature) {
  //   return {
  //       fillColor: '<?php echo e($kecamatan->warna); ?>',
  //       weight: 2,
  //       opacity: 1,
  //       color: '<?php echo e($kecamatan->warna); ?>',
  //       dashArray: '3',
  //       fillOpacity: 0.4
  //   };
  //   }

  //   //fungsi untuk menggunakan geojson
  //   L.geoJSON(geojson_id, {
  //   style: style
  //   }).addTo(map).bindTooltip('<?php echo e($kecamatan->nama); ?>');


  //   }).fail(function(){
  //   console.log("An error has occurred.");
  //   });
  //   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    var options = {
          series: <?php echo e(json_encode($total)); ?>,
          chart: {
          width: 300,
          type: 'donut',   
        },
      donut: {
        expandOnClick: false
      },
        labels:  <?php echo e(json_encode($tahun)); ?>,
        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 150
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };

        var chart = new ApexCharts(document.querySelector("#Chart"), options);
        chart.render();

        // var options = {
        //   series: [{
        //     name: "Desktops",
        //     data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
        // }],
        //   chart: {
        //   height: 350,
        //   type: 'area',
        //   stacked: false,
        //   zoom: {
        //     enabled: false
        //   }
          
        // },
        // toolbar: {
        //     autoSelected: 'zoom'
        //   },
        // dataLabels: {
        //   enabled: false
        // },
        // stroke: {
        //   curve: 'straight'
        // },
        // title: {
        //   text: 'Product Trends by Month',
        //   align: 'left'
        // },
        // grid: {
        //   row: {
        //     colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
        //     opacity: 0.5
        //   },
        // },
        // xaxis: {
        //   categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
        // }
        // };

        // var chart = new ApexCharts(document.querySelector("#grafik"), options);
        // chart.render();
       

        var jumlah = <?php echo e(json_encode($total)); ?>;
        var tahun  = <?php echo e(json_encode($tahun)); ?>;
        Highcharts.chart('grafik', {
          title : {
            text: 'Grafik Retribusi Per Tahun'
          },
          xAxis : {
            categories : tahun
          },
          yAxis : {
            title : {
              text : 'Jumlah Retribusi'
            }
          },
          // plotOptions : {
          //   series : {
          //     allowPointSelect: true
          //   }
          // },
          series: [
            {
              name: 'Jumlah Retribusi',
              data: jumlah
            }
          ]
        });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/dasboard.blade.php ENDPATH**/ ?>