
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/leaflet-routing-machine.css')); ?>" />
<style>
  #map { height: 90%; }

  .legend{
    background:white;
    padding:50px;
  }
  .info {
    padding: 20px;
    font: 14px/16px Arial, Helvetica, sans-serif;
    background: white;
    background: rgba(255,255,255,0.8);
    box-shadow: 0 0 15px rgba(0,0,0,0.2);
    border-radius: 5px;
    }

  .legend i {
    width: 18px;
    height: 18px;
    float: left;
    margin-right: 8px;
    opacity: 0.7;
    }


 </style> 
    <div class="container-xxl flex-grow-1 container-p-y">

    
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="/dasboard">Dasboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="/peta">Peta Persebaran Menara</a>
            </li>
            <li class="breadcrumb-item active">Rute Ke Menara</li>
          </ol>

                <div class="col-lg-12 mb-4 order-0">
                    <div class="col-xl ">
                        <div class="row mt-2">
                      
                          </div>

                        </div>
                    <div class="mb-3" id="map"></div>
                  
                    </div>
                  </div>
             
              <!-- / Content -->
            
            <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
        integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
        crossorigin=""></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
          
    <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>       
        <script src="<?php echo e(asset('dist/leaflet-routing-machine.js')); ?>"></script>
    
            

<script>

    

const mbAttr = 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
const mbUrl = 'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

const streets =  L.tileLayer('http://{s}.google.com/vt?lyrs=m&x={x}&y={y}&z={z}',{
                maxZoom: 20,
                subdomains:['mt0','mt1','mt2','mt3']
            })

const hybrid = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
	});

const map = L.map('map', {
    center:    [-1.5016624,102.1162189],
    zoom: 10,
    layers: [hybrid]
});

const baseLayers = {
    'OpenStreetMap': hybrid,
    'Streets': streets
};

const layerControl = L.control.layers(baseLayers).addTo(map);

const satellite = L.tileLayer('http://{s}.google.com/vt?lyrs=s&x={x}&y={y}&z={z}',{
                maxZoom: 20,
                subdomains:['mt0','mt1','mt2','mt3']
            })
layerControl.addBaseLayer(satellite, 'Satellite');



var curLocation = [-1.5016624,102.1162189];

            
var marker = new L.marker(curLocation, {
    draggable: 'true'
}).bindPopup("<b>Geser untuk mendapatkan Koordinat");

    


    var geojson_id = '';

            <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            // proses baca file json yang ada di path /asssets/files/
            // sesuaikan path ini dengan lokasi tempat kalian menyimpan file data geojson
            $.getJSON("<?php echo e(asset('storage/'.$kecamatan->geojson)); ?>", function(data){
                //deklarasi variable map dengan fungsi L.map
                geojson_id = data;//variabel yang isinya data geojson
                
                //style untuk geojson, silahkan ubah sesuai kebutuhan
        function style(feature) {
            return {
                fillColor: '<?php echo e($kecamatan->warna); ?>',
                weight: 2,
                opacity: 1,
                color: '<?php echo e($kecamatan->warna); ?>',
                dashArray: '3',
                fillOpacity: 0.4
            };
        }

        //fungsi untuk menggunakan geojson
        L.geoJSON(geojson_id, {
            style: style
        }).addTo(map).bindTooltip('<?php echo e($kecamatan->nama); ?>');
        

        }).fail(function(){
        console.log("An error has occurred.");
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function onLocationFound(e) {
		const radius = e.accuracy / 2;

		const locationMarker = L.marker(e.latlng).addTo(map)
			.bindPopup(`Lokasi Anda`).openPopup();

            L.Routing.control({
                waypoints: [
                    L.latLng(e.latlng),
                    <?php $__currentLoopData = $menaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    L.latLng(<?php echo e($menara->lat); ?>,<?php echo e($menara->long); ?>)
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            }).addTo(map);
	}

	function onLocationError(e) {
		alert(e.message);
	}

	map.on('locationfound', onLocationFound);
	map.on('locationerror', onLocationError);

	map.locate({setView: true, maxZoom: 16});  

        // L.Routing.control({
        //         waypoints: [
        //             L.latLng(-1.5016624,102.1162189),
        //             <?php $__currentLoopData = $menaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        //             L.latLng(<?php echo e($menara->lat); ?>,<?php echo e($menara->long); ?>)
        //             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        //         ]
        //     }).addTo(map);

         

</script>

           <?php $__env->stopSection(); ?>


//       
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/provider/peta/rute.blade.php ENDPATH**/ ?>