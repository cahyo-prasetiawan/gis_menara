

<?php $__env->startSection('content'); ?>


<!-- Page Header Start -->
<div class="container-fluid bg-white py-4  wow fadeIn" data-wow-delay="0.1s" >
  <div class="container text-center py-5" style="box-shadow: 0 2px">
      <h1 class=" text-black mb-4 animated slideInDown">Retribusi</h1>
      <nav aria-label="breadcrumb animated slideInDown">
          <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="/home">Dasboard</a>
              </li>
              <li class="breadcrumb-item active">Retribusi
              </li>
            
            </ol>
      </nav>
  </div>
</div>
<!-- Page Header End -->
<!-- Service Start -->
<div class="container-xxl py-5 flex-grow-1" >
   <div class="container">
       <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
          
        
       </div>
       <div class="row g-4">
        <div class="col-xl-3 col-md-2 col-12 invoice-actions">
            <div class="card">
              <div class="card-body">
                <form action="/halretribusi" method="get">
                    <div class="row mt-2">
                      <div class="col-8 p-0">
                        <select class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tahun">
                          <option value="">== Pilih Tahun ==</option>
                         
                         <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if(old('tahun', request('tahun')) == $year): ?>
                             <option value="<?php echo e($year->year); ?>" selected><?php echo e($year->year); ?></option>
                           <?php else: ?>
                             <option value="<?php echo e($year->year); ?>" ><?php echo e($year->year); ?></option>
                          <?php endif; ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                      <?php echo e($message); ?>

                      </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="col-3" style="padding-left:5px;">
                        <button type="submit"  class="btn btn-primary  ">Filter</button>
                      </div>
                    </div>
                    </form>
               
               
              </div>
            </div>
          </div>
        <div class="col-xl-9 col-md-8 col-12 mb-md-0 mb-4">
            <div class="card invoice-preview-card">
              <div class="card-body">
                <div class="d-flex justify-content-between flex-xl-row flex-md-column flex-sm-row flex-column p-sm-3 p-0">
                  <div class="mb-xl-0 mb-4">
                    <div class="d-flex svg-illustration mb-3 gap-2">
                      <span class="app-brand-logo demo">
                          <img src="<?php echo e(asset('logo.png')); ?>" style="width:50px;" alt="">
                      </span>
                      <span class="app-brand-text demo text-body fw-bolder"  style="text-transform: capitalize;">Diskominfo</span>
                    </div>
                    <p class="mb-1">Jl. RM. Thaher No. 503 Muara Bungo 37214</p>
                    <p class="mb-1">Email :info@bungokab.go.id</p>
                    <p class="mb-0">Telp : 0747-21016</p>
                  </div>
                  <div>
                   
                    <h4>Retribusi #<?php echo e($sekarang); ?></h4>
                    <div>
                      <span class="me-1">Jatuh Tempo:</span>
                      <?php $__currentLoopData = $tahunT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <span class="fw-semibold"><?php echo e(Carbon\Carbon::parse($tahun->jatuh_tempo)->locale('id_ID')->isoFormat('LL')); ?></span><br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <span class="fw-semibold">Keterangan : </span><br>
                      <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($status->status == 1): ?>
                      <h5 class="fw-bold text-center">Lunas</h5>
                      <?php else: ?>
                      <h5 class="fw-bold text-center text-danger">Belum Dibayar</h5>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                 
                  </div>
                </div>
              </div>
              <hr class="my-0" />
             
              <div class="table-responsive">
                <table class="table border-top m-0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Menara</th>
                      <th>kecamatan</th>
                      <th>Alamat</th>
                      <th>Jenis menara</th>
                      <th>Tagihan</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
                      function rupiah($angka)
                  {
                      // $prefix = $prefix ? $prefix : 'Rp. ';
                      // $nominal = $this->attributes[$field];
                      // return $prefix . number_format($nominal, 0, ',', '.');
                      $hasil = "Rp. " . number_format($angka, '2', ',' , '.');
                      return $hasil;
                  }
                  ?>
                   <?php if(count($menara)>0): ?>
                      <?php $__currentLoopData = $menara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($menara->nama); ?></td>
                        <td><?php echo e($menara->knama); ?></td>
                      <td><?php echo e($menara->alamat); ?></td>
                      <td style="text-center"><?php echo e($menara->jnama); ?> Kaki</td>
                      <td><?php echo e(rupiah($menara->tarif)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <td colspan="6">
                     <h5 class="text-center">Tidak ada Tagihan</h5>
                    </td>
                   <?php endif; ?>
      
                    <tr>
                      <td colspan="3" class="align-top px-4 py-5">
                        <p class="mb-2">
                          <span class="me-1 fw-semibold">Kepada:</span>
                          <span><?php echo e(Auth::user()->name); ?></span>
                        </p>
                        <span>Terima Kasih</span>
                      </td>
                      <td class="text-end px-4 py-5">
                        <p class="mb-0">Total: </p>
                      </td>
                      <td class="px-4 py-5">
                        <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="fw-semibold mb-0"> <?php echo e(rupiah($total->tagihan)); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
        
              <div class="card-body">
                <div class="row">
                  <div class="col-12">
                      <span class="fw-semibold">Catatan:</span>
                      <span>Bukti Catatan Penagihan Retribusi </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
       </div>
    
   </div>
</div>
<!-- Service End -->










<?php $__env->stopSection(); ?>
<?php echo $__env->make('interface.parsial.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/interface/retribusi.blade.php ENDPATH**/ ?>