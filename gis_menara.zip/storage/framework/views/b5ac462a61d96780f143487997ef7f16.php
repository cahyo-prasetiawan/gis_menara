

<?php $__env->startSection('content'); ?>


<!-- Page Header Start -->
<div class="container-fluid bg-white py-4  wow fadeIn" data-wow-delay="0.1s" >
  <div class="container text-center py-5" style="box-shadow: 0 2px">
      <h1 class="display-2 text-black mb-4 animated slideInDown">Menara</h1>
      <nav aria-label="breadcrumb animated slideInDown">
          <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="/home">Dasboard</a>
              </li>
              <li class="breadcrumb-item active">Menara
              </li>
            
            </ol>
      </nav>
  </div>
</div>
<!-- Page Header End -->
<!-- Service Start -->
<div class="container-xxl py-5 flex-grow-1" >
   <div class="container">
       <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
          
        
       </div>
       <div class="row g-4">

        <?php $__currentLoopData = $tampil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="team-item rounded overflow-hidden pb-4">
                <img class="img-fluid mb-4" src="<?php echo e(asset('storage/'.$menara->foto)); ?>" width="50%" alt="">
                <h5><?php echo e($menara->menara); ?></h5>
                <span class="text-primary"><?php echo e($menara->nama); ?></span><br>
                
                    
                    <li><a class="btn btn-primary" href=""><?php echo e($menara->tinggi); ?></a></li>
                    <li><a class="btn btn-primary" href=""><?php echo e($menara->tahun); ?></a></li>
                    <li><a class="btn btn-primary" href=""><?php echo e($menara->jenis_id); ?></a></li>
                    <li><a class="btn btn-primary" href=""><?php echo e($menara->alamat); ?></a></li>
                </ul>
            </div>
        </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
    
       </div>
    
   </div>
</div>
<!-- Service End -->










<?php $__env->stopSection(); ?>
<?php echo $__env->make('interface.parsial.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/interface/detail.blade.php ENDPATH**/ ?>