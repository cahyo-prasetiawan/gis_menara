<?php echo e($slot); ?>

<?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>