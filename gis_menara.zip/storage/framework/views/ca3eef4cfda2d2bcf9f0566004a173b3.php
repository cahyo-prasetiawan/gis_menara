<nav
class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
id="layout-navbar"
>
<div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
  <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
    <i class="bx bx-menu bx-sm"></i>
  </a>
</div>

<div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
  <!-- Search -->
  <div class="navbar-nav align-items-center">
    <div class="nav-item d-flex align-items-center">
     
    </div>
  </div>
  <!-- /Search -->

  <ul class="navbar-nav flex-row align-items-center ms-auto">
    <!-- Place this tag where you want the button to render. -->
    <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-3 me-xl-1">
      <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
        <i class="bx bx-bell bx-sm"></i>
        <?php if( auth()->user()->unreadNotifications->count() > 0): ?>
        <span class="badge bg-danger rounded-pill badge-notifications"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
        <?php else: ?>
        <?php endif; ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end py-0">
        <li class="dropdown-menu-header border-bottom">
          <div class="dropdown-header d-flex align-items-center py-3">
            <h5 class="text-body mb-0 me-auto">Notification</h5>
            <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
            <a href="/readAll" class="dropdown-notifications-all text-body" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Mark all as read" data-bs-original-title="Mark all as read"><i class="bx fs-4 bx-envelope-open"></i></a>
            <?php else: ?>

            <?php endif; ?>
          </div>
        </li>
        <?php if(Auth::user()->role == '0'): ?>
        <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="dropdown-notifications-list scrollable-container ps">
          <ul class="list-group list-group-flush">
            <li class="list-group-item list-group-item-action dropdown-notifications-item">
              <a href="<?php echo e(url($notification->data['url']. '?id='. $notification->id )); ?>">
              <div class="d-flex">
                <div class="flex-grow-1">
                  <h6 class="mb-1"><?php echo e($notification->data['title']); ?></h6>
                  <p class="mb-0"><?php echo e(ucwords($notification->data['message'])); ?></p>
                  <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                </div>
                <div class="flex-shrink-0 dropdown-notifications-actions">
                  
                  <a href="" class="dropdown-notifications-read"><span class="badge badge-dot"></span></a>
                  <a href="" class="dropdown-notifications-archive"><span class="bx bx-x"></span></a>
                </div>

              </div>
              </a>
            </li>
          
          </ul>
        <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div>
        <div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="dropdown-notifications-list scrollable-container ps">
          <ul class="list-group list-group-flush">
            <li class="list-group-item list-group-item-action dropdown-notifications-item">
              <a href="/read/<?php echo e($notification->id); ?>">
              <div class="d-flex">
                <div class="flex-grow-1">
                  <h6 class="mb-1"><?php echo e($notification->data['title']); ?></h6>
                  <p class="mb-0"><?php echo e(ucwords($notification->data['message'])); ?></p>
                  <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                </div>
                <div class="flex-shrink-0 dropdown-notifications-actions">
                  
                  <a href="" class="dropdown-notifications-read"><span class="badge badge-dot"></span></a>
                  <a href="" class="dropdown-notifications-archive"><span class="bx bx-x"></span></a>
                </div>

              </div>
              </a>
            </li>
          </ul>
        <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div>
        <div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
        <li class="dropdown-menu-footer border-top">
          <a href="javascript:void(0);" class="dropdown-item d-flex justify-content-center p-3">
            View all notifications
          </a>
        </li>
        <?php else: ?>
        <li class="dropdown-menu-footer border-top">
          <a href="javascript:void(0);" class="dropdown-item d-flex justify-content-center p-3">
            Tidak Ada Notifikasi
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </li>

   
    
    <li class="nav-item navbar-dropdown dropdown-user dropdown">
      <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
        <div class="avatar avatar-online">
          <?php if(Auth::user()->image == ''): ?>
          <img src="<?php echo e(asset('../assets/img/avatars/1.png')); ?>" alt class="w-px-40 h-auto rounded-circle" />
          <?php else: ?>
          <img src="<?php echo e(asset('storage/'.Auth::user()->image)); ?>" alt class="w-px-40 h-40 rounded-circle" />
          <?php endif; ?>
        </div>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li>
          <a class="dropdown-item" href="#">
            <div class="d-flex">
              <div class="flex-shrink-0 me-3">
                <div class="avatar avatar-online">
                  <?php if(Auth::user()->image == ''): ?>
                  <img src="<?php echo e(asset('../assets/img/avatars/1.png')); ?>" alt class="w-px-40 h-auto rounded-circle" />
                  <?php else: ?>
                  <img src="<?php echo e(asset('storage/'.Auth::user()->image)); ?>" alt class="w-px-40 h-40 rounded-circle" />
                  <?php endif; ?>
                  </div>
              </div>
              <div class="flex-grow-1">
                <?php if(Str::length(Auth::guard('user')->user()) > 0): ?>
                <span class="fw-semibold d-block"><?php echo e(Auth::guard('user')->user()->name); ?></span>
                <?php elseif(Str::length(Auth::guard('pengguna')->user()) > 0): ?>
                <span class="fw-semibold d-block"><?php echo e(Auth::guard('pengguna')->user()->name); ?></span>
                <?php endif; ?>
                <small class="text-muted">Role</small> : 
                <?php if(Auth::user()->role == '1'): ?>
                <span class="badge rounded-pill bg-danger">Admin</span>
                <?php elseif(Auth::user()->role == '0'): ?>
                <span class="badge rounded-pill bg-info">Pegawai</span>
                <?php elseif(Auth::pengguna()): ?>
                <span class="badge rounded-pill bg-secondary">Proveider</span>
                <?php endif; ?>
              </div>
            </div>
          </a>
        </li>
        <li>
          <div class="dropdown-divider"></div>
        </li>
        <li>
          <a class="dropdown-item <?php echo e(Request::is('myprofile*') ? 'active' : ''); ?>" href="/myprofile"> 
            <i class="bx bx-user me-2"></i>
            <span class="align-middle">My Profile</span>
          </a>
        </li>
       
        
        <li>
          <div class="dropdown-divider"></div>
        </li>
        <li>
          <form action="/logout" method="POST">
            <?php echo csrf_field(); ?>
          <button class="dropdown-item" type="submit"> <i class="bx bx-power-off me-2"></i> <span class="align-middle">Keluar</span></button>
          </form>
        </li>
      </ul>
    </li> 
  </ul>
</div>
</nav><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/partials/navbar.blade.php ENDPATH**/ ?>