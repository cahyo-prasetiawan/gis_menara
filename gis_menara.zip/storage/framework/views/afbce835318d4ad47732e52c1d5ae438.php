
<?php $__env->startSection('content'); ?>
<style>
  #map { height: 90%; }

  .legend{
    background:white;
    padding:50px;
    font-size: 7px;
  }
  .info {
    padding: 10px;
    font: 12px/14px Arial, Helvetica, sans-serif;
    background: white;
    background: rgba(255,255,255,0.8);
    box-shadow: 0 0 15px rgba(31, 30, 30, 0.2);
    border-radius: 5px;
    }

  .legend i {
    width: 18px;
    height: 18px;
    float: left;
    margin-right: 8px;
    opacity: 0.7;
    
    }


 </style> 
    <div class="container-xxl flex-grow-1 container-p-y">

      <?php echo e(Breadcrumbs::render('peta')); ?>


                <div class="col-lg-12 mb-4 order-0">
                    <div class="col-xl ">
                        <div class="row mt-2">
                            <div class="col-md-3">
                                <form action="/peta" method="get">   
                            <select class=" form-control <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="provider_id" name="provider_id" >
                                <option value="">== Pilih Provider ==</option>
                              <?php $__currentLoopData = $pemilik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemilik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if(old('pemilik_id') == $pemilik->id): ?>
                              <option value="<?php echo e($pemilik->id); ?>" selected><?php echo e($pemilik->name); ?></option>
                              <?php else: ?>
                              <option value="<?php echo e($pemilik->id); ?>"> <?php echo e($pemilik->name); ?></option>
                              <?php endif; ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['pemilik_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-md-4">
                           
                        <div class="row">
                            <div class="col-7">
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-company2" class="input-group-text"
                                ><i class="bx bx-broadcast"></i></span>
                              <select class="form-control <?php $__errorArgs = ['menara_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="menara_id" name="menara_id" onchange="cari(this.value)">
                            </select>
                              <?php $__errorArgs = ['menara_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="col-2 ">
                            <button type="submit" class="btn btn-primary">Cari</button>
                          </div>
                        </div>
                        </form>
                          </div>
                       
                          
                        </div>
                    <div class="mb-3" id="map"></div>
                  
                    </div>
                  </div>
              </div>
              <!-- / Content -->
              
            </div>
            <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
        integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
        crossorigin=""></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
          
        <script src="<?php echo e(asset('../dist/leaflet.markercluster-src.js')); ?>"></script>
    
            <script>

         

              $(document).ready(function() {
                $("#provider_id").select2({
                    theme: 'bootstrap5',
                    placeholder: "Pilih Provider"
                });

                $('#provider_id').on('change', function(){
                    var kode_provider = $(this).val();
                    console.log(kode_provider);
                    if (kode_provider) {
                        $.ajax({
                            url:'/cari/' + kode_provider,
                            type: 'GET',
                            data: {
                                '_token': '<?php echo e(csrf_token()); ?>'
                            },
                            dataType: 'json',
                            success: function(data){
                               if (data) {
                                // console.log(data);
                                $('#menara_id').empty();
                                $('#menara_id').append('<option class"form-control" value="">== pilih ===</option>');
                               
                                $.each(data,function(nama,kode){
                    $("#menara_id").append('<option class"form-control" value="'+kode.id+'">'+kode.nama+'</option>');
                });
                               } else {
                                
                               }
                            }
                        });
                    } else{

                    }
                    });

                  

                });

                
                // const point = L.layerGroup();

                // <?php $__currentLoopData = $menaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                //     var towerIcon<?php echo e($menara->id); ?> = L.icon({
                //         iconUrl: '<?php echo e(asset('/storage/'.$menara->icon)); ?>',
                //         iconSize:     [30, 40], // size of the icon
                //     });
                //     L.marker([<?php echo e($menara->lat); ?>,<?php echo e($menara->long); ?>], {icon: towerIcon<?php echo e($menara->id); ?>}).addTo(point)
                //     .bindPopup("<img class='img-thumbnail' style='width:80px;' src='<?php echo e(asset('storage/'.$menara->foto)); ?>'><br><b><?php echo e($menara->nama); ?></b><br><br><a class='btn btn-success mb-1 p-1' href='/menaraDetail/<?php echo e($menara->id); ?>'>Detail</a> <a class='btn btn-success mb-1 p-1' href='/menaraRute/<?php echo e($menara->id); ?>'>Rute</a>");
                //     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                const mbAttr = 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
                const mbUrl = 'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

                const streets =  L.tileLayer('http://{s}.google.com/vt?lyrs=m&x={x}&y={y}&z={z}',{
                                maxZoom: 20,
                                subdomains:['mt0','mt1','mt2','mt3']
                            })

                const hybrid = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        maxZoom: 19,
                        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                    });

                const map = L.map('map', {
                    center:    [-1.5016624,102.1162189],
                    zoom: 10,
                    layers: [hybrid]
                });

                const baseLayers = {
                    'OpenStreetMap': hybrid,
                    'Streets': streets
                };

                // const overlays = {
                //         'Point': point
                //     };

                const layerControl = L.control.layers(baseLayers).addTo(map);

                const satellite = L.tileLayer('http://{s}.google.com/vt?lyrs=s&x={x}&y={y}&z={z}',{
                                maxZoom: 20,
                                subdomains:['mt0','mt1','mt2','mt3']
                            })
                layerControl.addBaseLayer(satellite, 'Satellite');

                // var markers = L.markerClusterGroup();
                
                var curLocation = [-1.5016624,102.1162189];

            
                var mark = new L.marker(curLocation, {
                    draggable: 'true'
                }).bindPopup("<b>Geser untuk mendapatkan Koordinat");

                    
                    <?php $__currentLoopData = $menaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    var towerIcon<?php echo e($menara->id); ?> = L.icon({
                        iconUrl: '<?php echo e(asset('/storage/'.$menara->icon)); ?>',
                        iconSize:     [30, 40], // size of the icon
                    });
                  var marker =  L.marker([<?php echo e($menara->lat); ?>,<?php echo e($menara->long); ?>], {icon: towerIcon<?php echo e($menara->id); ?>}).bindPopup("<img class='img-thumbnail' style='width:80px;' src='<?php echo e(asset('storage/'.$menara->foto)); ?>'><br><b><?php echo e($menara->nama); ?></b><br><br><a class='btn btn-success text-black mb-1 p-1' href='/menaraDetail/<?php echo e($menara->id); ?>'>Detail</a> <a class='btn btn-warning text-black mb-1 p-1' href='/menaraRute/<?php echo e($menara->id); ?>'>Rute</a>");
                    marker.addTo(map);
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                  

                    var legend = L.control({position: 'bottomright'});
                legend.onAdd = function(mymap){
                    var div = L.DomUtil.create('div', 'info legend');
                    labels = ['<strong>Provider</strong>'],
                   
                    categories = [' <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($provider->name); ?>',' <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> '];
                
                        for (var i = 0; i < categories.length; i++) {
                               
                            if(i==0){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/c.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }else if(i==1){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/d.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }else if(i==2){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/e.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==3){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/er.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==4){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/g.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==5){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/i.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==6){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/in.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==7){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/k.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==8){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/p.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==9){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/t.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==10){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/s.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else if(i==11){
                                div.innerHTML += 
                                labels.push(
                                    '<img width="10" height:"20" class="img-thubnail" src="<?php echo e(asset('icon/te.png')); ?>" >' +
                                (categories[i] ? categories[i] : '+'));
                            }
                            else{
                                div.innerHTML += 
                                labels.push();

                            }
                            }
                            div.innerHTML = labels.join('<br>');
                        return div;
                        };



                    var geojson_id = '';

                    <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    // proses baca file json yang ada di path /asssets/files/
                    // sesuaikan path ini dengan lokasi tempat kalian menyimpan file data geojson
                    $.getJSON("<?php echo e(asset('storage/'.$kecamatan->geojson)); ?>", function(data){
                        //deklarasi variable map dengan fungsi L.map
                        geojson_id = data;//variabel yang isinya data geojson
                        
                         //style untuk geojson, silahkan ubah sesuai kebutuhan
                function style(feature) {
                    return {
                        fillColor: '<?php echo e($kecamatan->warna); ?>',
                        weight: 2,
                        opacity: 1,
                        color: '<?php echo e($kecamatan->warna); ?>',
                        dashArray: '3',
                        fillOpacity: 0.4
                    };
                }
 
                //fungsi untuk menggunakan geojson
                L.geoJSON(geojson_id, {
                    style: style
                }).addTo(map).bindTooltip('<?php echo e($kecamatan->nama); ?>');
                   
 
            }).fail(function(){
                console.log("An error has occurred.");
            });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            legend.addTo(map);
         
           

            function cari($id)
            {
           
           
            }
       
        
    </script>
           <?php $__env->stopSection(); ?>


//       
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bismillah skripsi\aplikasi\gis_menara\resources\views/provider/peta/index.blade.php ENDPATH**/ ?>