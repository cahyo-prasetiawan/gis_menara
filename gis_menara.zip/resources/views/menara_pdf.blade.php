<html>
 
                    <head>
                    <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Laporan Surat </title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">


   <!-- Theme style -->
   <link rel="stylesheet" href="dist/css/adminlte.min.css">
<link rel="stylesheet" href="assets/css/costom.css">


</head>
                    </head>
                  <link rel="stylesheet" href="assets/cetak.css">
                  <style type="text/css" media="print">
                    @page{
                        size: auto;
                        margin: 0.2cm;
                    
                    }
                  </style>
                  <!-- Main content -->
                        <div class="row">
                            <div class="col-12">
                                <div class="card aku">
                                <div class="card-header atas text-center">
                                    <img src="../pegawai/assets/img/kop.png" alt="" style="width:100%; padding:0;">
                                <!-- /.card-header -->
                                    <h2>Laporan Surat
                                        ?></h2>
                                 </div>
                                <div class="card-body kua">
                                    <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                    
                                        </div>
                                        <div class="row kia justify-content-center">
                                            <div class="col-sm-12">
                                                <table id="example1" class="table table-bordered table-striped dataTable dtr-inline" role="grid" aria-describedby="example1_info">
                                    <thead class="thead-dark">
                                    <tr role="row">
                                   asa
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                            </div>
                                <!-- /.card-body -->
                                </div>
                                <div class="card-footer ">
                                    <div  style="font-weight:500;padding-left:950px; ">
                                        Kepala Dinas
                                    </div>
                                    <div style="padding-left:940px; margin-top:40px; ">
                                     Zainadi.S.Pd.,MM
                                    </div>
                                    <div style="padding-left:920px;">
                                    197106121995021001	
                                    </div>
                                </div>
                                <!-- /.card -->
                            </div>
                            <!-- /.col -->
                            </div>
                            <script type="text/javascript">
                                window.print();
                            </script>
                          
  </html>